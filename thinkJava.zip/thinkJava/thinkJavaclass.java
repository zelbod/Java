package thinkJava;

import thinkJava.JTime;

public class thinkJavaclass {

	public static void main(String[] args) {

	JTime startTime = new JTime(22, 50, 0.0);
	JTime runningTime = new JTime(5, 16, 0.0);
	JTime endTime = startTime.add(runningTime);
	System.out.println(endTime);
	}
}
