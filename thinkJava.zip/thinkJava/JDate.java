package thinkJava;

import thinkJava.Date;
public class JDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date = new Date (04, 02, 2012);
		System.out.println(date);
	}

}
