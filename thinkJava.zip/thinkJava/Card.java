package thinkJava;

public class Card {

	public static final String[] RANKS = {
		null, "Ace", "2", "3", "4", "5", "6", "7", 
		"8", "9", "10", "Jack", "Queen", "King"};
	public static final String [] SUITS = {
		"Clubs", "Diamonds", "Hearts", "Spades"};
	
	private final int rank;
	//Ace - 1
	//Jack - 11
	//Queen - 12
	//King - 13
	private final int suit;
	//Clubs - 0
	//Diamonds - 1
	//Hearts - 2
	//Spades - 3

public Card(int rank, int suit){
	this.rank = rank;
	this.suit = suit;
}
public String toString(){
return RANKS[this.rank] + " of " + SUITS[this.suit];
	}
public int compareTo(Card that){
	if(this.suit < that.suit){
		return -1;
	}
	if(this.suit > that.suit){
		return 1;
	}
	if(this.rank < that.rank){
		return -1;
	}
	if(this.rank > that.rank){
		return 1;
	}
	if(this.rank == 1 && that.rank == 13){
		return 1;
	}
	if(this.rank == 13 && that.rank == 1){
		return -1;
	}
	return 0;
	}
public int getRank() {
	return this.rank;
	}
public int getSuit() {
	return this.suit;
	}
}
