package thinkJava;

public class JTime {
	private int hour;
	private int minute;
	private double second;

public JTime(int hour, int minute, double second){
	this.hour = hour;
	this. minute = minute;
	this.second = second;
	}

public JTime() {
	this.hour = 0;
	this. minute = 0;
	this.second = 0.0;
}

public int getHour(){
	return this.hour;
}

public int getMinute() {
	return this.minute;
}

public double getSecond() {
	return this.second;
}

public void setHour(int hour){
	this.hour = hour;
}

public void setMinute(int minute){
	this.minute = minute;
}

public void setSecond(int second){
	this.second = second;
}

public String toString(){
	return String.format("%02d:%02d:%04.1f\n", 
			this.hour, this.minute, this.second);
}

public boolean equals (JTime that){
	return this.hour == that.hour
		&& this.minute == that.minute
		&& this.second == that.second;
}

public JTime add(JTime t2){
	JTime sum = new JTime();
	sum.hour = this.hour + t2.hour;
	sum.minute = this.minute + t2.minute;
	sum.second = this.second + t2.second;
	sum.increment(t2.second);
	return sum;
}

 public void increment (double seconds){
	this.second += seconds;
	while(this.second >= 60.0){
		this.second -= 60.0;
		this.minute += 1;
	}
	while(this.minute >= 60.){
		this.minute -=60;
		this.hour +=1;
	}
	while(this.hour >= 24){
		int result = this.hour - 24;
		this.hour = result;
	}
	
	
}
}
