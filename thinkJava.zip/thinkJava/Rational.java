package thinkJava;

public class Rational {
private int numerator;
private int denominator;

public Rational(){
	this.numerator=0;
	this.denominator=1;
}
public void printRational(){
	System.out.printf("%d/%d",
			this.numerator, this.denominator);
}
public String toString(){
 	return String.format("%d/%d", 
			this.numerator, this.denominator);
}
public void negate(){
	this.numerator = -0;
	this.denominator = 1;
	System.out.printf("-%d/%d",
			this.numerator, this.denominator);
}
public void invert(){

	Rational reverse = new Rational();
	reverse.numerator = this.numerator;
	reverse.denominator = this.denominator;
	System.out.printf("%d/%d",
			reverse.denominator, reverse.numerator);
}
public void toDouble(){
	double x = 0.0;
	double y = 0.0;
	x = this.numerator;
	y = this.denominator;
	System.out.printf("%f/%f",
			x, y);
}
public void Rationals(int numerator, int denominator){
	int result = 0;
	while (denominator>0){
	result = numerator%denominator;	
	numerator = denominator;
	denominator = result;
	}
	System.out.println(numerator);
}
public void Rational (int numerator, int denominator){
	Rationals(numerator, denominator);
}
}

