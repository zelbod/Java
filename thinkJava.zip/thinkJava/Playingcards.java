package thinkJava;
import thinkJava.Card;

public class Playingcards {
public static Card[] makeDeck(){
	Card[] cards = new Card[52];
	int index = 0;
	for (int suit = 0; suit <=3; suit++){
		for(int rank = 1; rank <= 13; rank++){
			cards[index] = new Card (rank, suit);
			index++;
		}
	}
	return cards;
}
public static void printDeck(Card[] cards){
	for (int i = 0; i<cards.length; i++){
		System.out.println(cards[i]);
	}
}
public static int search(Card[] cards, Card target){
	for (int i = 0; i < cards.length; i++){
		if(cards[i].equals(target)){
			return 1;
		}
	}
	return -1;
	
}
public static int binarySearch(Card[] cards, Card target){
	int low = 0;
	int high = cards.length - 1;
	
	System.out.println(low + ", " + high);
	while (low<=high){
		int mid = (low + high) / 2;
		int comp = cards[mid].compareTo(target);
		
		if(comp == 0){
			return mid;
		} else if (comp < 0){
			low = mid + 1;
		} else {
			high = mid - 1;
		}
	}
	return -1;
}
public static int suitHist(Card[] cards){
	int count = 0;
	for (int i = 0; i < cards.length ; i++){	
		for (int y = i+1; y < cards.length; y++){
			if(cards[i].getSuit()==cards[y].getSuit()){
				count++;
				y=cards.length;
			}
		}
	}
	
	return count;
}
public static boolean hasFlush(Card[] cards){
	if(cards.length<5){
		return false;
	}
	for (int i = 1; i < cards.length; i++){
		for (int y = i-1; y < cards.length; y++){
			if(cards[y].getSuit()==cards[i].getSuit()){
				y = cards.length;
			}else{
				return false;
			}
		}		
	}
	
	return true;
}
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Card sample = new Card(5, 3);
	Card[] samples = new Card[] {new Card(10,3), new Card(2,3), new Card(8,3), 
			new Card(9,3), new Card(3,3), new Card(5,3)};
//	for (int i = 0; i<samples.length; i++){
//	System.out.println(samples[i]);
//	}
	System.out.println(hasFlush(samples));
	
	}
}
