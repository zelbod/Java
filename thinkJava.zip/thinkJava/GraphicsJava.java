package thinkJava;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import javafx.scene.layout.Border;

import javax.swing.JFrame;
import javax.swing.border.LineBorder;

public class GraphicsJava extends Canvas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame("Japan");
		Canvas canvas = new GraphicsJava(); 
		canvas.setSize(400,200);
		canvas.setBackground(Color.white);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
	}
	public void paint(Graphics g) {
		g.translate(100, 0);
		g.setColor(Color.RED);
		g.fillOval(50, 50, 100, 100);
		}

}
