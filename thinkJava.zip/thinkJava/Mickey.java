package thinkJava;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;

public class Mickey extends Canvas {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Moire Pattern");
        Canvas canvas = new Mickey();
        canvas.setSize(400, 400);
        canvas.setBackground(Color.white);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
    }

    public void paint(Graphics g) {
    	int cx = getWidth()/2;       // x coordinate of the center
		int cy = getHeight()/2;
		int skip = 40;
		
		for (int x = 0; x < getWidth(); x+=skip)
		{
			// line from center to top
			g.drawLine (cx, cy, x, 0);
			// line from center to bottom
			g.drawLine (cx, cy, x, getHeight());
		}		
		for (int y = 0; y < getHeight(); y+=skip)
		{
			// line from center to left
			g.drawLine (cx, cy, 0, y);
			// line from center to right
			g.drawLine (cx, cy, getWidth(), y);
		}
    }
}


