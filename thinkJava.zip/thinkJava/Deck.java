package thinkJava;

import java.util.Arrays;
import java.util.Random;

/**
 * A deck of playing cards (of fixed size).
 */
public class Deck {


	private Card[] cards;
    public final Random random =  new Random();

    /**
     * Constructs a standard deck of 52 cards.
     */
    public Deck() {
        this.cards = new Card[52];
        int index = 0;
        for (int suit = 0; suit <= 3; suit++) {
            for (int rank = 1; rank <= 13; rank++) {
                this.cards[index] = new Card(rank, suit);
                index++;
            }
        }
    }

    /**
     * Constructs a deck of n cards (null).
     */
    public Deck(int n) {
        this.cards = new Card[n];
    }

    /**
     * Gets the internal cards array.
     */
    public Card[] getCards() {
        return this.cards;
    }

    /**
     * Displays each of the cards in the deck.
     */
    public void print() {
        for (int i = 0; i < this.cards.length; i++) {
            System.out.println(this.cards[i]);
        }
    }

    /**
     * Returns a string representation of the deck.
     */
    public String toString() {
        return Arrays.toString(this.cards);
    }

    /**
     * Chooses a random number between low and high, including both.
     */
    public int randomInt(int low, int high) {
    	Random x = this.random;
    	int z = x.nextInt(high + 1);
    	while(z < low){
    		z = x.nextInt(high + 1);
    	}
    	return z;
    }

    /**
     * Swaps the cards at indexes i and j.
     */
    public void swapCards(int i, int j) {
    	Card[] card = this.cards;
    	Card a = card[i];
    	Card b = card[j];
    	card[i] = b;
    	card[j] = a;
    }

    /**
     * Randomly permutes the array of cards.
     * @return 
     */
    public void shuffle() {
    	for(int i = 0; i < cards.length; i++){
    		int z = randomInt(0, cards.length-1);
    		swapCards(i, z);
    	}
    }

    /**
     * Finds the index of the lowest card
     * between low and high inclusive.
     */
    public int indexLowest(int low, int high) {
    	Card[] card = this.cards;
    	//Initialising z  
    	int z = 0;
    	//loop through the card from low to high.
    	for (int i = low; i < high; i++){
    		//card x is each card
    		Card x = card[i];
    		//loop through card but starts from next card from first
    		for(int j = low+1; j <= high; j++){
    			Card y = card[j];
    			//compares card x to y 
    			z = x.compareTo(y);	
    			//if z is 1, the second loop will end with j = high
    			// if z is -1, it is the lowest card and will return j 
    			if(z == 1){
    				j = high;
    			} else if ( z == -1){
    				return j;
    			}
    		}
    	}
		return 0;
    }

    /**
     * Returns a subset of the cards in the deck.
     */
    public Deck subdeck(int low, int high) {
        Deck sub = new Deck(high - low + 1);
        for (int i = 0; i < sub.cards.length; i++) {
            sub.cards[i] = this.cards[low + i];
        }
        return sub;
    }

    /**
     * Combines two previously sorted subdecks.
     */
    public static Deck merge(Deck d1, Deck d2) {
    	Deck result = new Deck(52);
    	int i = 0;
    	int j = 0;
    	int s = 0;
    	//-1 = winner, lowest card wins.
    	for (int k = 0; k < result.cards.length; k++){
//    		running K
    		if (d1.cards.length == i){
//    			if the length of the deck d1 is same as i
    			s = -1;
//    			s is 1
    		}else if (d2.cards.length == j){
//    			if the length of the deck d2 is same as j
    			s = 1;
//    			s is -1
    		}else{
    			s = d1.cards[i].compareTo(d2.cards[j]);
//    			else compare deck d1, card at i with deck d2, card at j
    		}
    		if(s == 1){
//    			if the result is 1, (compareTo:-1 lowest, 1 greatest)
    			result.cards[k] = d1.cards[i];
//    			the card at position [k] is the card at deck d1, card position i
    			i++;
//    			i = i + 1. this keeps a counter (later be used if one of the deck is empty)
    		}else if (s == -1){
//    			else if the result is -1,
    			result.cards[k] = d2.cards[j];
//				the card at the position [k], is the card at the deck d2, card position j	
    			j++;
//    			j = j + 1
    		}
    	}
    	
    	
        return result;
    }
    
    /**
     * Sorts the cards (in place) using selection sort.
     */
    public void selectionSort() {
    	Card[] card = this.cards;
    	for (int i = 0; i < card.length; i++){
    		for(int j = 0; j < card.length; j++){
    			int x = card[i].compareTo(card[j]);
	    		if(x == 1){
	    		swapCards(i, j);
	    		}
    		}
    	}
    }
    
    /**
     * Returns a sorted copy of the deck using merge sort.
     */
    public Deck mergeSort() {
    	if(this.mergeSort().cards.length==0 ||
    			this.mergeSort().cards.length==1){
    		return mergeSort();
    	}
    	Deck d1 = mergeSort().subdeck(0, 25);
    	Deck d2 = mergeSort().subdeck(26, 51);
    	Deck result = new Deck(52);
    	int n = 0;
    	
        return result.merge(d1, d2);
    }
    
	public Deck almostMergeSort() {
	    	Deck d1 = this.subdeck(0, 25);
	    	Deck d2 = this.subdeck(26, 51);
	    	d1.selectionSort();
	    	d2.selectionSort();
	        return merge(d1, d2);
	    }

    /**
     * Reorders the cards (in place) using insertion sort.
     */
    public void insertionSort() {
    }

}
