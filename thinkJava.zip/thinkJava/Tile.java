package thinkJava;

import java.io.PrintStream;

public class Tile {
	
	private char letter;
	private int value;


public Tile (char letter, int value){
	this.letter = letter;
	this.value = value;
}

public int getletter(){
	return this.letter;
}
public int getvalue(){
	return this.value;
}
public void setletter(char letter){
	this.letter = letter;
}
public void setvalue(int value){
	this.value = value;
}
public String toString(){
	return String.format("%c %d", this.letter, this.value);
}
public boolean equals(Tile equals){
	return this.letter==equals.letter 
			&& this.value == equals.value;
}
}