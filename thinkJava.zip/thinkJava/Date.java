package thinkJava;

public class Date {
	private int date;
	private int month;
	private int year;

public Date(){
	this.date = 0;
	this.month = 0;
	this.year = 0;
}
	
public Date (int date, int month, int year){
	this.date = date;
	this.month = month;
	this.year = year;
}
public String toString(){
	return String.format("%02d/%02d/%02d", 
			this.date, this.month, this.year);
}
}
