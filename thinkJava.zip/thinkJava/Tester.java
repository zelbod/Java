package thinkJava;

import thinkJava.Deck;

public class Tester {
	public static void main(String[] args) {
//		Deck dac = new Deck(); 
//		dac.shuffle();
////		dac.selectionSort();
////		Deck sub = dac.subdeck(0, 25);
////		Deck sub2 = dac.subdeck(26, 51);
////		sub.selectionSort();
////		sub2.selectionSort();
////		dac.merge(sub, sub2);
////		System.out.println(	dac.almostMergeSort());
//		System.out.println(dac.mergeSort());
				System.out.println(factorial(5));
	}
	public static int factorial(int n) {
		if (n == 0) {
		return 1;
		}
		int recurse = factorial(n - 1);
		int result = n * recurse;
		return result;
		}
}
